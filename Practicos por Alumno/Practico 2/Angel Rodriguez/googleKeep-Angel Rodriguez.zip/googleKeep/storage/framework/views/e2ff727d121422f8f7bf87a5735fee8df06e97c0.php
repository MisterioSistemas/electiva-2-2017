<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Pacial Nro 1, Juan Angel Rodriguez M.</title>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <!--  <link rel="stylesheet" href="/resources/demos/style.css">-->



        <style>

            .column {
                width: 200px;
                float: left;
                padding-bottom: 100px;
            }
            .portlet {
                margin: 0 1em 1em 20px;
                padding: 0.3em;
            }
            .portlet-header {
                padding: 0.2em 0.3em;
                margin-bottom: 0.5em;
                position: relative;
            }
            .portlet-toggle {
                position: absolute;
                top: 50%;
                right: 0;
                margin-top: -8px;
            }
            .portlet-content {
                padding: 0.4em;
            }
            .portlet-placeholder {
                border: 1px dotted black;
                margin: 0 1em 1em 0;
                height: 50px;
            }
        </style>

        <script src="<?php echo e(asset('js/jquery-3.1.0.min.js')); ?>" type="text/javascript"></script>
        <!--<script src="https://code.jquery.com/jquery-1.12.4.js"></script>-->

        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <link href="http://fonts.googleapis.com/css?family=Roboto:400,700,300|Material+Icons" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo e(asset('css/material-dashboard.css')); ?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo e(asset('css/demo.css')); ?>" rel="stylesheet" type="text/css"/>

        <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/chartist.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/material-dashboard.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/material.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/bootstrap-notify.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('js/demo.js')); ?>" type="text/javascript"></script>


        <script>
            $(function() {
            $(".column").sortable({
            connectWith: ".column",
                    handle: ".portlet-header",
                    cancel: ".portlet-toggle",
                    placeholder: "portlet-placeholder ui-corner-all"
            });
            $(".portlet")
                    .addClass("ui-widget ui-widget-content ui-helper-clearfix ui-corner-all")
                    .find(".portlet-header")
                    .addClass("ui-widget-header ui-corner-all")
                    .prepend("<span class='ui-icon ui-icon-minusthick portlet-toggle'></span>");
            $(".portlet-toggle").on("click", function() {
            var icon = $(this);
            icon.toggleClass("ui-icon-minusthick ui-icon-plusthick");
            icon.closest(".portlet").find(".portlet-content").toggle();
            });
            });
        </script>


    </head>
    <body>

        <div class="wrapper">

            <div class="sidebar" data-color="green" data-image="../assets/img/sidebar-1.jpg">
                <!--
                Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

                Tip 2: you can also add an image using data-image tag
                -->

                <div class="logo" style="background-color: #fb0">
                    <a href="#" class="simple-text">
                        <b>Angel</b> Keep
                    </a>
                </div>

                <div class="sidebar-wrapper">
                    <ul class="nav">
                        <li>
                            <a href="dashboard.html">
                                <i class="material-icons">home</i>
                                <p>Inicio</p>
                            </a>
                        </li>
                        
                        <li>
                            <a href="table.html">
                                <i class="material-icons">content_paste</i>
                                <p>Nueva Nota</p>
                            </a>
                        </li>
                        <li>
                            <a href="user.html">
                                <i class="material-icons">person</i>
                                <p>User Profile</p>
                            </a>
                        </li>
                        
                    </ul>
                </div>
            </div>

            <div class="main-panel">
                <nav class="navbar navbar-transparent navbar-absolute" style="background-color: #fb0">
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="#">Material Dashboard</a>
                        </div>
                        <div class="collapse navbar-collapse">
                            <ul class="nav navbar-nav navbar-right">
                                <li>
                                    <a href="#pablo" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="material-icons">dashboard</i>
                                        <p class="hidden-lg hidden-md">Dashboard</p>
                                    </a>
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="material-icons">notifications</i>
                                        <span class="notification">5</span>
                                        <p class="hidden-lg hidden-md">Notifications</p>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a href="#">Mike John responded to your email</a></li>
                                        <li><a href="#">You have 5 new tasks</a></li>
                                        <li><a href="#">You're now friend with Andrew</a></li>
                                        <li><a href="#">Another Notification</a></li>
                                        <li><a href="#">Another One</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#pablo" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="material-icons">person</i>
                                        <p class="hidden-lg hidden-md">Profile</p>
                                    </a>
                                </li>
                            </ul>

                            <form class="navbar-form navbar-right" role="search">
                                <div class="form-group  is-empty">
                                    <input type="text" class="form-control" placeholder="Search">
                                    <span class="material-input"></span>
                                </div>
                                <button type="submit" class="btn btn-white btn-round btn-just-icon">
                                    <i class="material-icons">search</i><div class="ripple-container"></div>
                                </button>
                            </form>
                        </div>
                    </div>
                </nav>

                <!--Aqui va el contenido-->
                <div class='content'>
                    <div class="container-fluid">
                        <br>
                        <div class="row">
                            <div class="column col-md-3">
                                <div class="portlet card">
                                    <div class="portlet-header card-header" data-background-color="green">
                                        <h4 class="title">Daily Sales</h4>
                                    </div>
                                    <div class="portlet-content card-content">
                                        <h4 class="title">Daily Sales</h4>
                                        <p class="category"><span class="text-success"><i class="fa fa-long-arrow-up"></i> 55%  </span> increase in today sales.increase in today sales.increase in today sales.increase in today sales.increase in today sales.</p>
                                    </div>
                                    <div class="card-footer">
                                        <div class="stats">
                                            <i class="material-icons" style=" color: #006699">edit</i><a href="#">Editar</a>
                                            <i></i>
                                            <i class="material-icons button" style=" color: #cc0000">delete</i><a href="#">Eliminar</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="portlet card">
                                    <div class="portlet-header card-header" data-background-color="green">
                                        <h4 class="title">Daily Sales</h4>
                                    </div>
                                    <div class="portlet-content card-content">
                                        <h4 class="title">Daily Sales</h4>
                                        <p class="category"><span class="text-success"><i class="fa fa-long-arrow-up"></i> 55%  </span> increase in today sales.</p>
                                    </div>
                                    <div class="card-footer">
                                        <div class="stats">
                                            <i class="material-icons">access_time</i> updated 4 minutes ago
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="column col-md-3">
                                <div class="portlet card">
                                    <div class="portlet-header card-header" data-background-color="green">
                                        <h4 class="title">Daily Sales</h4>
                                    </div>
                                    <div class="portlet-content card-content">
                                        <h4 class="title">Daily Sales</h4>
                                        <p class="category"><span class="text-success"><i class="fa fa-long-arrow-up"></i> 55%  </span> increase in today sales.</p>
                                    </div>
                                    <div class="card-footer">
                                        <div class="stats">
                                            <i class="material-icons">access_time</i> updated 4 minutes ago
                                        </div>
                                    </div>
                                </div>

                                <div class="portlet card">
                                    <div class="portlet-header card-header" data-background-color="green">
                                        <h4 class="title">Daily Sales</h4>
                                    </div>
                                    <div class="portlet-content card-content">
                                        <h4 class="title">Daily Sales</h4>
                                        <p class="category"><span class="text-success"><i class="fa fa-long-arrow-up"></i> 55%  </span> increase in today sales.</p>
                                    </div>
                                    <div class="card-footer">
                                        <div class="stats">
                                            <i class="material-icons">access_time</i> updated 4 minutes ago
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="column col-md-3">

                            </div>
                        </div>


                        <input class="input" onclick="demo.showNotification('top', 'center')">Top Center<div class="ripple-container"></div></input>

                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">
                            Launch demo modal
                        </button>



                        <!-- Large modal -->
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bs-example-modal-lg">Large modal</button>

                        <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
                            <div class="modal-dialog modal-lg" role="document">
                                <div class="modal-content">
                                    ...
                                </div>
                            </div>
                        </div>


                    </div>




                    <footer class="footer">
                        <div class="container-fluid">
                            <nav class="pull-left">
                                <ul>
                                    <li>
                                        <a href="#">
                                            Home
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            Company
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            Portfolio
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                            Blog
                                        </a>
                                    </li>
                                </ul>
                            </nav>
                            <p class="copyright pull-right">
                                &copy; <script>document.write(new Date().getFullYear())</script> <a href="http://www.creative-tim.com">Juan Angel Rosriguez</a>, Parcial Nro 1, Electiva de Programacion
                            </p>
                        </div>
                    </footer>
                </div>
            </div>

            <!-- Modals -->
            <!-- Modals -->
            
            <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="myModalLabel">Modal title</h4>
                        </div>
                        <div class="modal-body">
                            ...
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary">Save changes</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Terminan los Modals -->
            
        </div>






    </body>


</html>
